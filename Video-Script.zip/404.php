<?php 
$action=$_REQUEST['action'];
$title = ''.$site.'';
include 'includes/config.php';
?>
<div class=""> <div class="ad1"> <font color="red"><b>Page Not Found:</b></font> Page Not Found Please Return <a href="/">Home Page</a>.</div></div>
<?php
include 'includes/foot.php';
?>