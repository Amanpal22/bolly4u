<?php
include 'include/func.php';
echo'<div class="catRow"><a href="https://downloadnee.com/api?id='.$_GET["id"].'&format=mp4&quality=720">Download Mp4 Full HD [720p]</a></div>';
echo'<div class="catRow"><a href="https://downloadnee.com/api?id='.$_GET["id"].'&format=mp4&quality=360">Download WebM [360p]</a></div>';
echo'<div class="catRow"><a href="https://downloadnee.com/api?id='.$_GET["id"].'&format=mp4&quality=240">Download Mp4 [240p]</a></div>';
echo'<div class="catRow"><a href="https://downloadnee.com/api?id='.$_GET["id"].'&format=mp4&quality=144">Download 3gp [144p]</a></div>
';
?>