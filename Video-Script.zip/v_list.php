<?php
echo'<div class="fl odd">
<a class="fileName" href="/d/'.$link.'/'.$final.'-Getindia.html"><div><div><img src="https://i.ytimg.com/vi/'.$link.'/default.jpg" alt="'.$name.'"/></div><div>'.$name.'</div></div></a></div>';
?>
