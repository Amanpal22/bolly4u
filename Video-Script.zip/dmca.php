<?php 
$action=$_REQUEST['action'];
$title = 'DMCA Page of | '.$site.'';
include 'includes/config.php';
?>
<h2>DMCA And Disclaimer</h2>
<div class="catRow"> <div class="ad1"> <font color="red"><b>DMCA Note:</b></font> This file is not hosted on JioTune.Tk. All files are hosted on Youtube.Com. JioTune.Tk or it's owner will not responsible for any of Illigal or Pronographic content of Youtube.Com. If you got any Illigal files Showing here then please report on those files/videos to Youtube.Com for removing from youtube.com Thank you for understanding.</div></div>

<div class="catRow" style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› Please Read The Disclaimer Before Download Anything From JioTune.Tk</b></div><br/><div class="catRow" style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› This is a promotional WAPSITE only, All files placed here are for introducing purpose only.</b></div><br/>
<div class="catRow" style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› Please, buy original Video Songs/contents from author or developer site!</b></div><br/>
<div class="catRow" style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› If you do not agree to all the terms, please disconnect from this site now itself.</b></div><br/>
<div class="catRow" style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› By remaining at this site, you affirm your understanding and compliance of the above disclaimer and absolve this site of any responsibility henceforth</b></div><br/>
<div class="catRow" style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› All files found on this site have been collected from YouTube and are believed to be in the "public domain".</b></div><br/>
<div class="catRow" style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› All the logos and stuff are the property of their respective owners</b></div><br/>
<div class="catRow" style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› If you are the rightful owner of any contents posted here, and object to them being displayed or If you are one of representativities of copy rights department and you dont like our conditions of store, Please Contact YouTube support team to hide your content from the web!</b></div><br/>
<div class="catRow" style ="border-bottom:1px dashed rgb(187, 187, 187)"><b>› Downloading at your own risk!!! </b></div>
<?php
include 'includes/foot.php'; 
?>