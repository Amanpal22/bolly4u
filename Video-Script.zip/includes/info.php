<?php

$site = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'';

$host = $_SERVER['HTTP_HOST'];

$sitename ='GetIndiaHost.Com'; // Your Site Name

$google = 'R_LnVSgpoEJzJIY26QMqTSo4sbGH2vao1FrE4_RcdaM'; //Google Verification Code

$alexa = 'Alexa Verification Code'; //Alexa Verification Code

$bing = 'Bing Web master Tool ID'; //Bing Verification Code

$mail = 'Yourmail@email_address'; //Your Email Here
$info = 'Welcome To Youtube Download Zone';
$adb =''; // nothing
$adt = ''; // nothing


$keywords ='Free, downmload, video, youtube, api v3, youtube downloader to mp3, mp3, 3gp, webm, popular, news, on the spot, gaming, music, hollywood, bollywood, disney, animation, animal, funny, movies, films, konser, sinetron';
?>