<?php include'ucweb.php';?>
<?php
include 'includes/info.php';
?>
<h2><center><font color="white">
<a href="/dmca.php">DMCA And Disclaimer</a> | 
&copy; <?php echo date("Y") ?> <a href="/"><?php echo ''.$sitename.'';?></font></a>
</center></h2>

<!--This Site Hosted On GetindiaHost.com -->

<!-- BEGIN: Powered by Supercounters.com -->
<center><script type="text/javascript" src="//widget.supercounters.com/ssl/online_t.js"></script><script type="text/javascript">sc_online_t(1449190,"Online","170ddb");</script><br><noscript><a href="http://www.supercounters.com/">Free Users Online Counter</a></noscript>
</center>
<!-- END: Powered by Supercounters.com -->



</body>
</html>