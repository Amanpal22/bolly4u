<?php
include 'info.php';
?>
<!doctype html><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="index, follow" />
<?php $title=str_replace("#"," ", $title);
 $title=str_replace("&"," ", $title);
$title=str_replace("$"," ", $title);
$title=str_replace("!"," ", $title); 
$title=str_replace("?"," ", $title);
$title=str_replace("|"," ", $title);
$title=str_replace("-"," ", $title); 
$title=str_replace("("," ", $title);
$title=str_replace(")"," ", $title);
$title=str_replace("+"," ", $title); 
$title=str_replace("@"," ", $title);
$title=str_replace('"',' ', $title);
$title=str_replace("["," ", $title);
$title=str_replace("]"," ", $title);
$title=str_replace("*"," ", $title);
$title=str_replace(","," ", $title);
$title=str_replace("="," ", $title);
$title=str_replace("?"," ", $title);
$title=str_replace("/"," ", $title);
$title=str_replace("'"," ", $title);
$title=str_replace("_"," ", $title);
$title=str_replace(";"," ", $title);
$title=str_replace("%"," ", $title);
$title=str_replace("^"," ", $title);
?>
<title><?php echo substr( $title, 0, 150 );?> Free Download</title>
<meta name="description" content="<?php echo substr( $title, 0, 157 ); ?> Live Streaming And Free Download youtube videos"/>
<meta name="msvalidate.01" content="AF1BFBD104E7F0B649DCF75FC40485D5" />
<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW, ARCHIVE" />
<meta name="robot" content="index,follow">
<meta name="copyright" content="Copyright © 2017 ® All Rights Reserved.">
<link rel="sitemap" href="/sitemap.xml" title="Getindiahost.com Site Map"/>
<meta name="country" content="India" />
<meta name="GOOGLEBOT" content="INDEX, FOLLOW"/>
<meta name="Distribution" content="Global" />
<meta name="keywords" content="<?php echo substr( $title, 0, 155 ); ?>"/>
<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW, ARCHIVE" />
<meta property="og:title" content="<?php echo $title;?>"/>
<meta property="og:url" content="http://<?php echo $host;?>/"/>
<meta property="og:image" content="http://<?php echo $host;?><?php echo $logo;?>"/>
<link rel="icon" href="/images.jpg" type="image/x-icon" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<style type="text/css">
body{ color:gray; font-family:Play; margin: 0; padding: 0; font-size:14px; line-height:20px;}
a:hover{ color: green; background-color: ; text-decoration: none; font-family:Comic Sans MS; font-size: 14px; }
body *{ margin: 0; padding: 0; }
a img, :link img, :visited img { border: none; }
a:visited{color:blue;}
a	{ text-decoration:none; color: red; padding:5px;}
a:hover { text-decoration: }
b{ font-weight:bold; }
a { padding:5px;}
.tCenter{ text-align:center; }
.logo { color: #fff; background: url(/images/bg.gif)repeat-x; text-align: center; padding-top: 4px; padding-bottom: 4px; }
.copyright {font-size:normal;display:block;background:#3D8CD7;padding:5px;color:#fff;text-align:center;font-weight:bold;}
hr{ background-color:#EEE; border:medium none; height:1px; margin:2px 0; padding:0;}
hr{ background-color:#EEE; border:medium none; height:1px; margin:2px 0; padding:0;}
h1,h2,h3{background:red; color:#fff;
#E91E63;padding: 5px;font-size: medium;margin: 2px 0px 0 0px;border-top-left-radius: 2px;-moz-border-top-left-radius: 5px;-webkit-border-top-left-radius: 5px;border-top-right-radius: 5px;-moz-border-top-right-radius: 5px;-webkit-border-top-right-radius: 5px;text-align:center;border-bottom:2px solid #00BFFF; text-shadow: 1px 1px 1px #00BFFF; text-align:center;border-bottom-left-radius: 2px;-moz-border-bottom-left-radius: 5px;-webkit-border-bottom-left-radius: 5px;border-bottom-right-radius: 5px;-moz-border-bottom-right-radius: 5px;-webkit-border-bottom-right-radius: 5px;text-align:center; }
h1 { text-align:center; }
h2 a{ color:#ffffff; }
.randomFile h3{ text-align:left; }
.search	{ background: #edecea; border:1px solid #d7ccc5; padding:8px; font-weight:bold; text-align:center; }
.pgn { background:#f5f5f5; border:1px solid #ddd; padding:5px 0; text-align:center; }
.pgn form { padding-top:5px; }
.pgn a, .pgn span { padding:2px 5px; margin:0 1px; font-weight:bold; -moz-border-radius:5px; -webkit-border-radius:5px; }
.pgn a { border:1px solid #ccc; background:#ddd; }
.pgn div { padding-top:5px; }
.pgn span,.pgn a:hover { border:1px solid #ddd; background:#fff; }
catRow	a,.catRowHome a{ display:block; background:url(/images/arrow.png) no-repeat left center; padding:8px; padding-left:23px;}
.catRow,.catRowHome { background-color: #fff; border-top: 1px solid #eeeeee; padding: 1px; font-weight: bold; }
.catRow	a,.catRowHome a { display:block; font-weight:bold; background:url(/images/arrow.png) right center no-repeat; padding:9px; }
.catRow:hover, .catRowHome:hover{ background-color:#f5f5f5; }
.catRow img { border-radius:5px; margin-right:3px; }
.catRow a div{ vertical-align:middle; display:table-cell; }
.catRow a div span,
.catRowHome a div span,{ font-size:x-small; color:#5a5; font-weight:normal; }
.catRowHome	{ border-bottom:1px solid #ddd; font-weight:bold;}
.catRowHome:hover { background:#f5f5f5; }
.catRowHome a { display:block; padding:8px; }
.catRowHome div { display:table-cell; }
.catRowHome img { border-radius:10px; margin-right: 3px;}
.catRowHome a div span,
.catRowHome a { display:block; background:url(../images/arrow.gif) no-repeat left center; padding-left:20px;}
.odd, .even, .sl	{ vertical-align:middle; }
.odd a{ color:red;font-weight:bold; }
.even a { background:; color:green;font-weight:bold; }
.fileName	{ font-weight:bold;  display:inline-block; }
.fileName	span{ color:#555; text-decoration:none;}
.fileName	img{ padding-right:3px;}
.tblimg	{ width:5px; text-align:left; }
.fl { }
.fl td{ padding:5px; border-bottom:1px solid #ccc; }
.fl a{ vertical-align:middle; padding:8px; }
.fl img{ padding:1px; border-radius:10px; }
.fl div{ display:table-cell; }
.fl { border-bottom:1px solid #ccc;}
.fl:hover { text-decoration:none; background:#f5f5f5; }
.fl span{ color:#000; font-weight:normal;}
.fl a{ }
.fl a img{ margin-right:3px; border:none; border-radius:10px;}
.fl a div div{ vertical-align:middle; display:table-cell; }
.fl a div{ }
table	{ width:100%; margin:auto;}
.devider	{ }
.dtype	{ border-bottom:1px solid #ccc; font-size:x-small; padding:5px; text-align:center; }
img{ vertical-align:middle; }
.showimage{ padding:5px; text-align:center; vertical-align:middle; border:none; border-radius:10px;}
.siteLink a { color:#fff; }
.ad1 { background:#eee; border:1px solid #ddd; color:#222;  }
.ad1 a { color:#222; }
.fl { border-bottom:1px solid #ddd; background:#fff;}
.fl:hover	{background:pink;color:blue;}
.fl span{ font-weight:normal; }
.fl span.mc { font-size:80%; }
.fl span.alb { color: #67b241; font-style:italic;}
.fl span.ar { color: #d2691e; font-style:italic;}
.fl a{ display:block; padding:8px; }
.fl a img{ border: 1px solid #ddd; border-radius: 3px; padding:0;margin-right:5px;}

.folder {
    width: 25px;
    height: 15px;
    display: inline-block;
    margin: auto;
    position: relative;
    background-color: orange;
    border-radius: 0 3px 3px 3px;
    margin: 8px;
    float: left;
}

table {width: 100%; margin: auto;}
.downLink{margin:5px 0;}
.dwnLink {font-weight:bold;} 
.downLink a {margin:5px; background:red; border-radius: 5px; color:#fff; padding:9px 12px; text-shadow: 1px 1px 1px #333; font-size:120%; display:inline-block;} .downLink a:hover {background:#47b5e4;}</style>
</head>
<body>
<center>
<div style="padding-bottom:10px;padding-top:11px;background:red;"><a href="/"> <b><font color="orange" size="27">Get</font><font color="white" size="27">IndiaHost</font><font color="lime" size="27">.Com </font></b></a></div></center>
<div class="ad1"> <div class="search" align="center"><b>
Search Videos:</b>
<br/>
<form action="/search.php" method="get">
<input type="text" name="q" placeholder="Search In Here"/> 
<input type="submit" value="Search" title="Search Now"/>
</form>
</div></div>